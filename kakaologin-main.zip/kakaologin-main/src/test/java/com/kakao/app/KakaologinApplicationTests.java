package com.kakao.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KakaologinApplicationTests {

	@Test
	void contextLoads() {
	}

}
