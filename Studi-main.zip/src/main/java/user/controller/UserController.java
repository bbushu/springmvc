package user.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import user.bean.UserDTO;
import user.service.UserService;

import javax.servlet.http.HttpSession;
import java.util.Collections;
import java.util.Map;

@Controller
@RequestMapping(value = "/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/save")
    public String writeForm(){
        return "user/save";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute UserDTO userDTO) {
        int saveResult = userService.save(userDTO);
        if (saveResult > 0) {
            return "user/login";
        } else {
            return "user/save";
        }
    }

    @GetMapping("/login" )
    public String loginForm(){
        return "user/login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute UserDTO userDTO,
                        HttpSession session) {
        boolean loginResult = userService.login(userDTO);
        if (loginResult) {
            session.setAttribute("loginEmail", userDTO.getUserId());
            return "index";
        } else {
            return "user/login";
        }
    }

}
