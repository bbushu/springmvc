package user.bean;

import lombok.*;

@Setter @Getter
@ToString
public class UserDTO {

    private String userId;
    private String userName;
    private String userPassword;
    private String phone;
    private String email;
    private String zipCode;
    private String addr1;
    private String addr2;
    private boolean agreement;

}
