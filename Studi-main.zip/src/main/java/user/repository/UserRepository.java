package user.repository;

import lombok.RequiredArgsConstructor;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;
import user.bean.UserDTO;

@Repository
@RequiredArgsConstructor
public class UserRepository {

    private final SqlSessionTemplate sql;

    public int save(UserDTO userDTO) {
        System.out.println("userDTO = " + userDTO);
        return sql.insert("User.save", userDTO);
    }

    public UserDTO login(UserDTO userDTO) {
        return sql.selectOne("User.login", userDTO);
    }

}
