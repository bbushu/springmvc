package user.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import user.bean.UserDTO;
import user.repository.UserRepository;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public int save(UserDTO userDTO) {
        return userRepository.save(userDTO);
    }

    public boolean login(UserDTO userDTO) {
        UserDTO loginMember = userRepository.login(userDTO);
        if (loginMember != null) {
            return true;
        } else {
            return false;
        }
    }
}
