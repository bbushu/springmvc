package studio.thinkground.aroundhub.util;

public interface PortalApi {
  String integrate();
}
