package studio.thinkground.aroundhub.config.env;

/**
 * PackageName : studio.thinkground.aroundhub.config.env FileName : EnvConfiguration Author :
 * Flature Date : 2022-05-08 Description :
 */
public interface EnvConfiguration {

  String getMessage();
}
